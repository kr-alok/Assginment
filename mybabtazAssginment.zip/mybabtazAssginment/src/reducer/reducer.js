import { combineReducers } from 'redux';
import GetDataReducer from './getdata/getservicedata.js'


export default combineReducers({
    GetDataReducer
   
})