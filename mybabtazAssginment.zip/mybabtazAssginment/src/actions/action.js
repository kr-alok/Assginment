import { GetDataAction } from './getdata/getservicedata.js'


export {
    GetDataAction
}