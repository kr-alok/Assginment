import React, { Component } from 'react';
import '../stylesheets/landingpage.css'
import $ from 'jquery'
import Testing from '../images/testing.jpg'
import profile from '../images/profile.jpg'

import * as action from '../actions/action.js'
import { connect } from 'react-redux'

const mapStateToProps = state => ({
    GetDataState: state.GetDataReducer.GetDataState,
})

const mapDispatchToProps = dispatch => ({
    fetchGetData() {
        dispatch(
            action.GetDataAction()
        )
    },
})


class LandingPageComp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            comment: "",
            array_empty: [],
            finalData: [],
            datafinal: []



        };


    }

    componentDidMount() {


        this.props.fetchGetData()


        var get_array = localStorage.getItem("cmntArrray");
        var array = JSON.parse("[" + get_array + "]");

        this.setState({
            datafinal: array
        })



    }



    onFieldchange(e) {

        e.preventDefault();

        this.setState({

            [e.target.name]: e.target.value
        }, () => {
            console.log(this.state)
        })
    }
    comment() {
        const { array_empty, finalData } = this.state
        const zee = this.state.comment
        var data = {
            "name": zee
        };
        array_empty.push(JSON.stringify(data))

        localStorage.setItem("cmntArrray", array_empty);
        var get_array = localStorage.getItem("cmntArrray");
        var array = JSON.parse("[" + get_array + "]");

        this.setState({
            datafinal: array
        })


    }

    render() {
        const { GetDataState } = this.props
        const { datafinal } = this.state
        console.log("hello" + datafinal)

        const height = $(window).height()
        return (
            <div className="col-sm-12 landingpage" style={{ minHeight: height,marginTop:"40px" }}>

                <div className="row">
                    <div className="col-sm-3" >

                        <div className="col-sm-12" style={{ border: "1px solid #ced4da",textAlign:"center" }}>
                            <img src={profile} alt="" style={{ height: "150px", width: "150px", borderRadius: "50%" }} />
                        </div>
                        <div style={{textAlign:"center"}}>
                             <span>Alok</span>
                            </div>

                           

                    </div>

                    <div className="col-sm-5">

                        {(GetDataState.length !== 0) ?
                            GetDataState.map((value, i) =>
                                <div className="panel panel-default">

                                    <div className="panel-heading conatiner">
                                        <div className="col-sm-12">
                                            <div className="row">
                                                <img src={GetDataState[i].author.profile_pic.fixed} alt="" />
                                                <h4>{GetDataState[i].author.name}</h4>

                                            </div>
                                        </div>

                                    </div>
                                    <div className="panel-body">
                                        <div className="col-sm-12" style={{ padding: "0px" }}>
                                            <div className="row">
                                                <div className="col-sm-12 profiledata" style={{ marginTop: "40" }}>
                                                    <div className="col-sm-12" style={{ textAlign: "center", background: "#f1f1f1" }}>
                                                        <img src={GetDataState[i].author.profile_pic.fixed} style={{ height: "80%", width: "50%" }} alt="" />
                                                        <div className="col-sm-12">

                                                        </div>

                                                        {(datafinal.length !== 0 && datafinal !== null) ?
                                                            datafinal.map((value, i) =>
                                                                <div> {datafinal[i].name} </div>
                                                            )
                                                            :
                                                            <div></div>
                                                        }
                                                        <div className="col-sm-12" style={{ marginTop: "10px" }}>
                                                            <textarea placeholder="please comment here..."
                                                                name="comment"
                                                                id={GetDataState[i].author.id}
                                                                onChange={this.onFieldchange.bind(this)}
                                                                rows="3"
                                                                cols="40">


                                                            </textarea>


                                                            <div className="col-sm-2 offset-sm-10">
                                                                <button type="button" class="btn btn-info"
                                                                    style={{ marginTop: "-82px", marginBottom: "15px" }}
                                                                    onClick={this.comment.bind(this)}
                                                                >Post</button>
                                                            </div>




                                                        </div>
                                                    </div>


                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                </div>

                            )
                            :
                            <div>No Records</div>

                        }

                    </div>

                    <div className="col-sm-4">
                        <div className="panel panel-default">
                            <div className="panel-heading" style={{ backgroundColor: "#818182", padding: "1px" }}>


                                <div className="col-sm-12">
                                    <div className="row">
                                        <img src={Testing} style={{ height: "10%", width: "8%", borderRadius: "50%" }} alt="" />
                                        <h4 style={{ fontweight: 400, padding: "0px 15px", fontSize: "16px", marginTop: "13px", color: "whitesmoke" }}>Top Brands</h4>

                                    </div>
                                </div>
                            </div>
                            <div className="panel-body" style={{ background: "#f1f1f1" }}>

                                {(GetDataState.length !== 0) ?
                                    GetDataState.map((value, i) =>

                                        <div className="col-sm-12">
                                            <div className="row">


                                                {
                                                    GetDataState[i].brands.map((value, j) =>

                                                        <div className="col-sm-12">
                                                            <div className="row">

                                                                <div className="col-sm-3">
                                                                    <img src={GetDataState[i].brands[j].brand_logo.medium} style={{ height: "100%", width: "50%" }} alt="" />

                                                                </div>

                                                                <div className="col-sm-7">
                                                                    {GetDataState[i].brands[j].name}
                                                                </div>

                                                            </div>

                                                        </div>



                                                    )

                                                }




                                            </div>
                                        </div>

                                    )
                                    :
                                    <div>No Records</div>

                                }





                            </div>

                        </div>




                    </div>



                </div>



            </div>



            // <div className="col-sm-12 mainpage" style={{ minHeight: height }}>
            //     <div className="col-sm-8 offset-sm-2 cardpage">
            //         <div className="row">
            //             {(GetDataState.length !== 0) ?
            //                 GetDataState.map((value, i) =>
            //                     <div className="col-sm-3 cardcontain">
            //                         <div className="row">
            //                             <div className="col-sm-12">
            //                                 <img src={GetDataState[i].small_image} className="productimg" alt="" />
            //                             </div>
            //                             <div className="col-sm-12 text-center">
            //                                 <span style={{ fontSize: "12px", fontWeight: "600", color: "#ddddd" }}>{GetDataState[i].name}</span>
            //                             </div>
            //                             <div className="col-sm-12 text-center">
            //                                 <span style={{ color: "red", fontWeight: 600,fontSize:"14px" }}>Size:</span>
            //                                 <span style={{ fontWeight: 600, fontSize: "11px" }}>{GetDataState[i].size}</span>
            //                             </div>
            //                             <div className="col-sm-12 text-center">
            //                                 <span style={{ color: "red", fontWeight: 600 }}>₹{GetDataState[i].price}</span>
            //                             </div>
            //                             <div className="col-sm-12 text-center">
            //                                 <button className="col-sm-5 btn btn-danger btn-sm">Buy Now</button>
            //                             </div>
            //                         </div>
            //                     </div>
            //                 )
            //                 :
            //                 <div>No Records</div>

            //         }

            //         </div>
            //     </div>

            // </div>
        )

    }
}
const LandingPage = connect(mapStateToProps, mapDispatchToProps)(LandingPageComp)
export default LandingPage
